package com.example.checkpoint02

import android.graphics.Color
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


import com.example.checkpoint02.databinding.ActivitySecondpageBinding

class SecondPage : AppCompatActivity() {

    private lateinit var binding: ActivitySecondpageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondpageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val backgroundColor = intent.getIntExtra("backgroundColor", Color.WHITE)
        binding.activitySecondPageLayout.setBackgroundColor(backgroundColor)

        binding.colorDisplayView.setBackgroundColor(backgroundColor)


        binding.backButton.setOnClickListener {
            finish()
        }
    }
}
