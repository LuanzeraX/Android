package com.example.checkpoint02

import android.graphics.Color
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

import com.example.checkpoint02.databinding.ActivityMainBinding
import yuku.ambilwarna.AmbilWarnaDialog

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedColor = Color.BLACK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.rgbRadioButton.isChecked = true

        binding.rgbLayout.visibility = View.VISIBLE
        binding.pickerLayout.visibility = View.GONE

        binding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                binding.rgbRadioButton.id -> {
                    binding.rgbLayout.visibility = View.VISIBLE
                    binding.pickerLayout.visibility = View.GONE
                }
                binding.pickerRadioButton.id -> {
                    binding.rgbLayout.visibility = View.GONE
                    binding.pickerLayout.visibility = View.VISIBLE
                    openColorPicker()
                }
            }
        }

        binding.setButton.setOnClickListener {

                val red = binding.redEditText.text.toString().toIntOrNull()
                val green = binding.greenEditText.text.toString().toIntOrNull()
                val blue = binding.blueEditText.text.toString().toIntOrNull()

                if (red != null && green != null && blue != null) {

                    val validRed = red.coerceIn(0, 255)
                    val validGreen = green.coerceIn(0, 255)
                    val validBlue = blue.coerceIn(0, 255)


                    val backgroundColor = Color.rgb(validRed, validGreen, validBlue)


                    val intent = Intent(this, SecondPage::class.java)
                    intent.putExtra("backgroundColor", backgroundColor)
                    startActivity(intent)
                } else {


                    Toast.makeText(this, "Preencha os campos", Toast.LENGTH_SHORT).show()
                }

        }
    }


    private fun openColorPicker() {
        val colorPicker = AmbilWarnaDialog(this, selectedColor, object : AmbilWarnaDialog.OnAmbilWarnaListener {
            override fun onCancel(dialog: AmbilWarnaDialog?) {
                // Handle cancel action
            }

            override fun onOk(dialog: AmbilWarnaDialog?, color: Int) {
                selectedColor = color
                binding.pickerLayout.setBackgroundColor(color)

            }
        })
        colorPicker.show()
    }
}
