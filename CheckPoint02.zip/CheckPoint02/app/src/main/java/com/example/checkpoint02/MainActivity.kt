package com.example.checkpoint02

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

import com.example.checkpoint02.databinding.ActivityMainBinding
import yuku.ambilwarna.AmbilWarnaDialog

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedColor = Color.BLACK // Cor inicial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.rgbRadioButton.isChecked = true


        binding.rgbLayout.visibility = View.VISIBLE
        binding.pickerLayout.visibility = View.GONE

        binding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                binding.rgbRadioButton.id -> {
                    binding.rgbLayout.visibility = View.VISIBLE
                    binding.pickerLayout.visibility = View.GONE
                }
                binding.pickerRadioButton.id -> {
                    binding.rgbLayout.visibility = View.GONE
                    binding.pickerLayout.visibility = View.VISIBLE
                    openColorPicker()
                }
            }
        }
    }

    private fun openColorPicker() {
        val colorPicker = AmbilWarnaDialog(this, selectedColor, object : AmbilWarnaDialog.OnAmbilWarnaListener {
            override fun onCancel(dialog: AmbilWarnaDialog?) {
                // Ação a ser executada ao cancelar a seleção de cor
            }

            override fun onOk(dialog: AmbilWarnaDialog?, color: Int) {
                // Manipule a cor selecionada aqui
                selectedColor = color
                binding.pickerLayout.setBackgroundColor(color)
            }
        })
        colorPicker.show()
    }
}

